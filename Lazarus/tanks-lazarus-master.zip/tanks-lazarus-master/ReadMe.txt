﻿Copyright (c) January 2012-2017, Martin C. Foster

Tanks is a game example written using Free Pascal Lazarus IDE. This development environment was selected because it is cross platform, easy to use, and provides performance comparable to C.

Game instructions:
You are provided with a blue tank.
Watch out for the red tanks. They will be shooting at you. If you are hit you loose.
Your mission is to destroy all of the red tanks before your time run out. Note the time counting down in the lower status bar. The faster you finish, the higher your score. the top ten scores will be recorded for posterity. 
The enemy will be scattered in four screens or plazas. To move from plaza to plaza, just move through the gap in the block walls at the edge of your plaza.

Controls:
Right arrow, 	Rotate right
Left arrow, 	Rotate left
Up arrow, 	Move forward
Space bar, 	Shoot

Be careful not to run into your own bullets.

